## Jack Compiler
 Jack Compiler is used to compile Jack source code into a virtual machine language which is further converted into machine code using vm translator  
 The Jack language is part of Nand2Tetris project (https://www.nand2tetris.org/)
 
## usage
 Run the JackCompiler.java file in a workspace and provide the folder directory of .jack files to compile
